

#define YY_NO_UNPUT

using namespace std;

#include <iostream>
#include <stdio.h>
#include <string>

int yyparse();
/*
int main(int argc, char **argv) {
   if (argc > 1) {
      //yyin = fopen(argv[1], "r");
      if (freopen(argv[1], "r", stdin)== NULL){
         //printf("syntax: %s filename\n", argv[0]);
		 cerr << argv[0] << ": ---> " << argv[1] << " is a baddie.\n";
		 exit(1);
      }//end if
   }//end if
   yyparse(); // Calls yylex() for tokens.
   return 0;
}
*/

int main(int argc, char **argv)
{
  if((argc > 1) && (freopen(argv[1], "r", stdin) == NULL))
    {
	    cerr << argv[0] << ": File " << argv[1] << " cannot be opened.\n";
		    exit(1);
			  }

			    yyparse();

				  return 0;
}
